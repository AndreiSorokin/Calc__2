# flutter-calculator
**Preview :**


https://user-images.githubusercontent.com/82409174/124909486-bcac6000-dfff-11eb-96ff-641df21570ae.mp4


# Explanation
A calculator for simple calculations.
Also you can save some of your calculations in the app or clear your history.

I will appreciate if you give star to this project.
The project will progress over the time.

# Resources
UI from : https://dribbble.com/sujatakushwaha

Used packages:
  hive,
  hive_flutter,
  math_expressions,
  provider, 
  build_runner and
  hive_generator.
